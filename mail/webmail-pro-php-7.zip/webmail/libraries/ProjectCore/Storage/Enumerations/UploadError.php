<?php

/*
 * Copyright 2004-2017, AfterLogic Corp.
 * Licensed under AGPLv3 license or AfterLogic license
 * if commercial version of the product was purchased.
 * See the LICENSE file for a full license statement.
 */

namespace ProjectCore\Storage\Enumerations;

/**
 * @category ProjectCore
 * @package Storage
 * @subpackage Enumerations
 */
class UploadError
{
	const UNKNOWN = 1000;
	const CONFIG_SIZE = 1001;
	const ON_SAVING = 1002;
	const EMPTY_FILES_DATA = 1003;
}

